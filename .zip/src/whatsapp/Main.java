package whatsapp;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import java.io.InputStream;
import java.net.URL;
public class Main extends Application {

    private VBox messageArea = new VBox();
    private ScrollPane scrollPane = new ScrollPane(messageArea); // Make scrollPane accessible

    @Override
    public void start(Stage stage) {
    	
    	try {
    		 URL resourceUrl = getClass().getResource("/main/resources/serviceAccountKey.json"); // Yeh line yahan dalni hai


    	    if (resourceUrl != null) {
    	        InputStream serviceAccountStream = resourceUrl.openStream();
    	        // Ab aap is stream ko use karke JSON file ko parse kar sakte hain
    	        System.out.println("JSON file loaded successfully!");
    	        // Example: If using Google Firebase Admin SDK:
    	       // FirebaseOptions options = FirebaseOptions.builder()
    	           // .setCredentials(GoogleCredentials.fromStream(serviceAccountStream))
    	           // .build();
    	       // FirebaseApp.initializeApp(options);
    	        serviceAccountStream.close();
    	    } else {
    	        System.err.println("Error: serviceAccountKey.json not found in resources.");
    	    }
    	} catch (Exception e) {
    	    e.printStackTrace();
    	}
    	
        // Top Bar
        HBox topBar = createTopBar();

        // Message Area (Center)
        scrollPane.setFitToWidth(true);
        messageArea.setSpacing(10);
        messageArea.setPadding(new Insets(10));
        // Removed messageArea background to allow individual message backgrounds to stand out
        // messageArea.setStyle("-fx-background-color: #f3e5ab;"); // Very light brown

        // Auto-scroll to bottom
        messageArea.heightProperty().addListener((obs, oldVal, newVal) -> {
            scrollPane.setVvalue(1.0);
        });

        // Bottom Bar
        HBox bottomBar = createBottomBar();

        // Main Layout
        BorderPane layout = new BorderPane();
        layout.setTop(topBar);
        layout.setCenter(scrollPane);
        layout.setBottom(bottomBar);

        Scene scene = new Scene(layout, 400, 600);
        stage.setScene(scene);
        stage.setTitle("WhatsApp Chatbot UI");
        stage.show();
    }

    private HBox createTopBar() {
        HBox topBar = new HBox(10);
        topBar.setPadding(new Insets(10));
        topBar.setAlignment(Pos.CENTER_LEFT);
        topBar.setStyle("-fx-background-color: white;");

        ImageView profilePic = new ImageView(new Image("https://via.placeholder.com/40"));
        profilePic.setFitHeight(40);
        profilePic.setFitWidth(40);
        Circle clip = new Circle(20, 20, 20);
        profilePic.setClip(clip);

        Label nameLabel = new Label("Jarurat Care");
        nameLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 16px;");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button videoBtn = new Button("\uD83D\uDCF9"); // Video Camera
        Button callBtn = new Button("\uD83D\uDCDE"); // Telephone receiver
        Button searchBtn = new Button("\uD83D\uDD0D"); // Magnifying glass

        topBar.getChildren().addAll(profilePic, nameLabel, spacer, videoBtn, callBtn, searchBtn);
        return topBar;
    }

    private HBox createBottomBar() {
        HBox bottomBar = new HBox(5);
        bottomBar.setPadding(new Insets(10));
        bottomBar.setAlignment(Pos.CENTER_LEFT);
        bottomBar.setStyle("-fx-background-color: white;");

        Button emojiBtn = new Button("\uD83D\uDE0A"); // Grinning face with smiling eyes
        Button attachBtn = new Button("\uD83D\uDCCE"); // Paperclip

        TextField inputField = new TextField();
        inputField.setPromptText("Type a message...");
        HBox.setHgrow(inputField, Priority.ALWAYS);
        inputField.setStyle("-fx-background-radius: 20; -fx-border-radius: 20; -fx-padding: 8 15;");


        Button sendBtn = new Button("\u27A4"); // Black right-pointing triangle
        sendBtn.setStyle("-fx-background-color: #25D366; -fx-text-fill: white; -fx-background-radius: 20; -fx-font-weight: bold;");


        inputField.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.ENTER) {
                String userMessage = inputField.getText().trim();
                if (!userMessage.isEmpty()) {
                    addMessage(userMessage, true); // User message
                    inputField.clear();
                    // Simulate bot response
                    addMessage("Bot: " + getBotResponse(userMessage), false); // Bot message
                }
            }
        });

        sendBtn.setOnAction(e -> {
            String userMessage = inputField.getText().trim();
            if (!userMessage.isEmpty()) {
                addMessage(userMessage, true); // User message
                inputField.clear();
                // Simulate bot response
                addMessage("Bot: " + getBotResponse(userMessage), false); // Bot message
            }
        });

        bottomBar.getChildren().addAll(emojiBtn, attachBtn, inputField, sendBtn);
        return bottomBar;
    }

    /**
     * Adds a message to the message area with appropriate styling.
     * @param message The text of the message.
     * @param isUser true if the message is from the user, false if from the bot.
     */
    private void addMessage(String message, boolean isUser) {
        Label msgLabel = new Label(message);
        msgLabel.setWrapText(true);
        msgLabel.setMaxWidth(300); // Limit message width to prevent very long lines

        HBox messageContainer = new HBox();
        messageContainer.getChildren().add(msgLabel);

        String backgroundColor;
        String textColor = "black";
        Pos alignment;

        if (isUser) {
            backgroundColor = "#DCF8C6"; // Light green for user messages
            alignment = Pos.CENTER_RIGHT;
            messageContainer.setAlignment(alignment);
            msgLabel.setStyle("-fx-background-color: " + backgroundColor + "; -fx-padding: 8; -fx-background-radius: 10; -fx-text-fill: " + textColor + ";");
        } else {
            backgroundColor = "white"; // White for bot messages
            alignment = Pos.CENTER_LEFT;
            messageContainer.setAlignment(alignment);
            msgLabel.setStyle("-fx-background-color: " + backgroundColor + "; -fx-padding: 8; -fx-background-radius: 10; -fx-text-fill: " + textColor + "; -fx-border-color: #E0E0E0; -fx-border-radius: 10;");
        }

        // Add padding around messages
        VBox messageWrapper = new VBox(messageContainer);
        messageWrapper.setPadding(new Insets(2, 0, 2, 0)); // Small vertical padding

        messageArea.getChildren().add(messageWrapper);
    }

    /**
     * Simple bot response logic.
     * @param userMessage The message from the user.
     * @return A simulated bot response.
     */
    private String getBotResponse(String userMessage) {
        userMessage = userMessage.toLowerCase();
        if (userMessage.contains("hello") || userMessage.contains("hi")) {
            return "Hello there! How can I help you?";
        } else if (userMessage.contains("how are you")) {
            return "I'm a bot, but I'm functioning perfectly!";
        } else if (userMessage.contains("help")) {
            return "I can answer questions about general topics. Try asking me something!";
        } else if (userMessage.contains("bye")) {
            return "Goodbye! Have a great day!";
        } else {
            return "I'm not sure how to respond to that. Can you rephrase?";
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}