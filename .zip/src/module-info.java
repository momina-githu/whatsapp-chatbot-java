module whatsapp {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;

    exports whatsapp;
    opens whatsapp to javafx.fxml;
}